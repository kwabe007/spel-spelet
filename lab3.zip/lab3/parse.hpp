#ifndef PARSE_HPP
#define PARSE_HPP

#include <string>

class Parse{
public:
    static void insert_names(std::string text);
};


#endif
