#ifndef TEXT_HPP
#define TEXT_HPP

#include <string>
#include <vector>
#include <iostream>
#include <parse.hpp>



#endif
