#include <fstream>
#include <iostream>
#include <string>

#include "parse.hpp"

void Parse::insert_names(std::string text){
    std::cout << "Hey world!" << std::endl;
}
