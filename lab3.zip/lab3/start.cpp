#include <iostream>


#include "text.hpp"

//Presents the introduction

void menu_screen() {

}

void intro() {

}


int main() {




    return 0;
}
