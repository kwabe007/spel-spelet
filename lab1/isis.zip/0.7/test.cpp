// template specialization
#include <iostream>
#include "kth_cprog_template_container.hpp"
#include <typeinfo>
using namespace std;

class NotMA
{
private:
    int cyka;
public:
    NotMA(){
        cyka = 0;
    }
    NotMA(const int i) {
        cyka = i;
    }
    NotMA(const NotMA& ref) {
        cyka = ref.cyka;
    }
    NotMA(NotMA&& ref) = delete;
};

template<typename T>
void printVector(const TVector<T>& vect) {
    for (T * it = vect.begin(); it != vect.end(); ++it) {
        cout << *it << endl;
    }
    cout << "Size: " << vect.size() << endl;
    cout << "Cap: " << vect.capacity() << endl;
}

int main () {
  NotMA notma(3);

  TVector<int> myint (7);
  TVector<float> myfloat;
  //TVector<NotMA> (2);
  for (int i =1;i<3;++i) {
    myint.push_back(i);
  }
  myfloat.push_back(22.05);
  cout << sizeof(long) << endl;
  cout << "myint" << endl;
  printVector(myint);
  myint.insert(2, 55);
  myint.erase(9);
  cout << "myint" << endl;
  printVector(myint);
  cout << "mychar" << endl;
  printVector(myfloat);
  std::cout << typeid(myfloat[1]).name() << '\n';

  return 0;
}
