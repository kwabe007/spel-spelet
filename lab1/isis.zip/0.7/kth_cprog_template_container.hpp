#ifndef TVECTOR
#define TVECTOR

#include <cstdio>
#include <stdexcept>
#include <algorithm>
#include <initializer_list>
#include <type_traits>

template <typename T>
class TVector{
    static_assert(std::is_move_assignable<T>::value,"Not move-assignable, asshole!");
    static_assert(std::is_move_constructible<T>::value,"Not move-constructible u cheeky scrub");
private:
    int vLength;
    int vCap;
    T * vPnData;

public:
    explicit TVector(){
        vLength = 0;
        vCap = 0;
        vPnData = nullptr;
    }
    TVector(std::initializer_list<T> list){
        vLength = list.size();
        vPnData = new T[list.size()];
        vCap = vLength;
        std::copy(list.begin(), list.end(), vPnData);
    }
    explicit TVector(const std::size_t vSize){
        //std::cout << "size_init" << std::endl;
        vLength = vSize;
        vCap = vLength;
        vPnData = new T[vSize];
    }
    explicit TVector(const std::size_t vSize, const T val){
        //std::cout << "double mambo!" << std::endl;
        vLength = vSize;
        vCap = vLength;
        vPnData = new T[vSize];
        for (int i = 0;i<vLength;++i) {
            vPnData[i]=val;
        }
    }
    TVector(const TVector& ref){
        vLength = ref.vLength;
        vCap = vLength;
        vPnData = new T(*ref.vPnData);
    }
    TVector& operator= (TVector const& ref) {
        if (this != &ref) {
            T * newVPnData = new T [ref.vCap];
            std::copy(ref.vPnData, ref.vPnData + ref.vLength, newVPnData);
            delete [] vPnData;
            vPnData = newVPnData;
            vLength = ref.vLength;
            vCap = vLength;
        }
        return *this;
    }

~TVector() {
    delete[] vPnData;
}

void reset() {
    for (int i = 0;i < vLength;++i) {
        vPnData[i] = 0;
    }
}
void clear() {
    delete [] vPnData;
    vLength = 0;
    vCap = 0;
    vPnData = nullptr;
}


std::size_t size() const {
    return vLength;
}
std::size_t capacity() const {
    return vCap;
}
void push_back(T val) {
    if (vLength == vCap) {
        allocate();
    }
    vPnData[vLength] = val;
    ++vLength;
}
void insert(const std::size_t index, T val) {
    if (index >= 0 && index < vLength){
        if (vLength == vCap) {
            allocate();
        }
        for (int i=vLength; i>index;--i) {
            vPnData[i] = *(vPnData + i - 1);
        }
        vPnData[index] = val;
        ++vLength;
    }else if (index == vLength) {
        push_back(val);
    } else {
        throw std::out_of_range("OUT OF RANGE, BITCH!");
    }
}
void erase(const std::size_t index) {
    if (index >= 0 && index < vLength){
        for (int i=index; i<vLength-1;++i) {
            vPnData[i] = *(vPnData + i + 1);
        }
        --vLength;
    } else {
        throw std::out_of_range("OUT OF RANGE, BITCH!");
    }
}
T * begin() const{
   if (vLength > 0) {
       return vPnData;
   } else {
       return nullptr;
   }
}
T * end() const{
   if (vLength > 0) {
       return vPnData+vLength;
   } else {
       return nullptr;
   }
}
T * find(T const& val) const{
   for (int i = 0; i < vLength; ++i) {
       if (vPnData[i] == val) {
           return vPnData + i;
       }
   }
   return vPnData+vLength;
}
void allocate() {
    if (vCap == 0) {
        vCap = 1;
    }
    vCap = vCap * 2;
    T * newVPnData = new T [vCap];
    std::copy(vPnData, vPnData + vLength, newVPnData);
    delete [] vPnData;
    vPnData = newVPnData;
}

T& operator[] (const int index) {
    if (index >= 0 && index < vLength) {
    return vPnData[index];
    }
    else {
        throw std::out_of_range("Index out of range");
    }
}
const T& operator[] (const int index) const {
    if (index >= 0 && index < vLength) {
    return vPnData[index];
    }
    else {
        throw std::out_of_range("Index out of range");
    }
}
};


#endif
