
#include <iostream>
#include <initializer_list>
#include "kth_cprog_simple_container.hpp"

int main() {
    unsigned int x = 44;
    unsigned int y = 45;

    UIntVector vect(22);
    UIntVector cyka(0);
    UIntVector blyad(44);
    UIntVector suckmynuts();
    vect[0] = 3;

    blyad = vect;
    std::initializer_list<unsigned int> il = {1,2,4};
    UIntVector suppa({1,2,4});
    int b = 0;
    //vect[2] = 222;
    //cyka[2] = 22;


    std::cout << vect[0] << " " << blyad.size() << std::endl;
    blyad[0] = 6;
    for (int q;q<suppa.size();++q) {
        std::cout << "elem nr"  << q << suppa[q];
    }
    std::cout << std::endl;
    std::cout << "SUPPA SIZE BIATCH: " << suppa.size() << " " << std::endl;
    return 0;
}
