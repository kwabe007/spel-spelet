#ifndef UINTVECTOR
#define UINTVECTOR

#include <cstdio>
#include <stdexcept>
#include <algorithm>
#include <initializer_list>
#include <type_traits>

template <typename T>
class UIntVector{
    static_assert(std::is_move_assignable<T>::value,"Not move-assignable, asshole!");
    static_assert(std::is_move_constructible<T>::value,"Not move-constructible u cheeky scrub");
private:
    int vLength;
    int vCap;
    T * vPnData;

public:
    explicit UIntVector(){
        vLength = 0;
        vCap = 0;
        vPnData = nullptr;
    }
    UIntVector(std::initializer_list<T> list){
        vLength = list.size();
        vPnData = new T[list.size()];
        vCap = vLength;
        std::copy(list.begin(), list.end(), vPnData);
    }
    explicit UIntVector(const std::size_t vSize){
        std::cout << "size_init" << std::endl;
        vLength = vSize;
        vCap = vLength;
        vPnData = new T[vSize];
    }
    explicit UIntVector(const std::size_t vSize, const T val){
        std::cout << "double mambo!" << std::endl;
        vLength = vSize;
        vCap = vLength;
        vPnData = new T[vSize];
        for (int i = 0;i<vLength;++i) {
            vPnData[i]=val;
        }
    }
    UIntVector(const UIntVector& ref){
        vLength = ref.vLength;
        vCap = vLength;
        vPnData = new T(*ref.vPnData);
    }
    UIntVector& operator= (UIntVector const& ref) {
        if (this != &ref) {
            T * newVPnData = new T [ref.vCap];
            std::copy(ref.vPnData, ref.vPnData + ref.vLength, newVPnData);
            delete [] vPnData;
            vPnData = newVPnData;
            vLength = ref.vLength;
            vCap = vLength;
        }
        return *this;
    }

~UIntVector() {
    delete[] vPnData;
}

void reset() {
    for (int i = 0;i < vLength;++i) {
        vPnData[i] = 0;
    }
}
void clear() {
    delete [] vPnData;
    vLength = 0;
    vCap = 0;
    vPnData = nullptr;
}

std::size_t size() const {
    return vLength;
}
std::size_t cap() const {
    return vCap;
}
void push_back(T val) {
    if (vLength == vCap) {
        if (vCap == 0) {
            vCap = 1;
        }
        vCap = vCap * 2;
        T * newVPnData = new T [vCap];
        std::copy(vPnData, vPnData + vLength, newVPnData);
        delete [] vPnData;
        vPnData = newVPnData;
        vPnData[vLength] = val;
        ++vLength;
    } else {
        vPnData[vLength] = val;
        ++vLength;
    }
}

T& operator[] (const int index) {
    if (index >= 0 && index < vLength) {
    return vPnData[index];
    }
    else {
        throw std::out_of_range("Index out of range");
    }
}
 T& operator[] (const int index) const {
    if (index >= 0 && index < vLength) {
    return vPnData[index];
    }
    else {
        throw std::out_of_range("Index out of range");
    }
}
};



#endif
