// template specialization
#include <iostream>
#include "kth_cprog_template_container.hpp"
#include <typeinfo>
using namespace std;

class NotMA
{
private:
    int cyka;
public:
    NotMA(){
        cyka = 0;
    }
    NotMA(const int i) {
        cyka = i;
    }
    NotMA(const NotMA& ref) {
        cyka = ref.cyka;
    }
    NotMA(NotMA&& ref) = delete;
};

template<typename T>
void printVector(const UIntVector<T>& vect) {
    for (int i=0; i<vect.size(); ++i) {
        cout << "Element " << i << ": " << vect[i] << endl;
    }
    cout << "Size: " << vect.size() << endl;
    cout << "Cap: " << vect.cap() << endl;
}

int main () {
  NotMA notma(3);

  UIntVector<int> myint (7);
  UIntVector<float> mychar;
  //UIntVector<NotMA> (2);
  for (int i =0;i<34;++i) {
    myint.push_back(22);
  }
  mychar.push_back(22.05);
  cout << "myint" << endl;
  printVector(myint);
  cout << "mychar" << endl;
  printVector(mychar);
  std::cout << typeid(mychar[1]).name() << '\n';

  return 0;
}
