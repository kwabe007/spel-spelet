
#include <iostream>
#include "UIntVector.h"
#include "a2dd.h"

int main() {
    unsigned int x = 44;
    unsigned int y = 45;

    UIntVector vect(1);
    vect[0] = 3;
    UIntVector cyka(0);
    UIntVector blyad(44);
    blyad = vect;
    //vect[2] = 222;
    //cyka[2] = 22;


    std::cout << vect[0] << " " << blyad[0] << std::endl;
    blyad[0] = 6;
    std::cout << vect[0] << " " << blyad[0] << std::endl;
    return 0;
}
