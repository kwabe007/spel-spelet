#ifndef UINTVECTOR
#define UINTVECTOR

#include <cstdio>
#include <stdexcept>
#include <algorithm>

class UIntVector;

class UIntVector {
private:
    int vLength;
    unsigned int* vPnData;

public:
    UIntVector(){
        vLength = 0;
        vPnData = 0;
    }
    UIntVector(const std::size_t vSize){
    vLength = vSize;
        vPnData = new unsigned int[vSize];
    }
    UIntVector(const UIntVector & ref){
        vLength = ref.vLength;
        vPnData = new unsigned int (*ref.vPnData);
    }
    UIntVector& operator= (UIntVector const& ref) {
        if (this != &ref) {
            unsigned int * newVPnData = new unsigned int [ref.vLength];
            std::copy(ref.vPnData, ref.vPnData + ref.vLength, newVPnData);

            delete [] vPnData;

            vPnData = newVPnData;
            vLength = ref.vLength;
        }

        return *this;
    }
    /*UIntVector() : vLength(0), vPnData(0)
    {
    }*/

~UIntVector() {
    delete[] vPnData;
}

void reset() {

}
std::size_t size() {
    return vLength;
}
unsigned int& operator[](const int index)
{
    if (index >= 0 && index < vLength) {
    return vPnData[index];
    }
    else {
        throw std::out_of_range("Index out of range");
    }
}
};



#endif
